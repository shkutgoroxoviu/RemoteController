//
//  TVConnectionManager.swift
//  RemoteTVController
//

import Foundation
import Combine

@MainActor
final class TVConnectionManager: ObservableObject {
    static let shared = TVConnectionManager()
    
    // MARK: - Published Properties
    @Published private(set) var connectionStatus: ConnectionStatus = .disconnected
    @Published private(set) var connectorState: ConnectorState = .idle
    @Published private(set) var connectedDevice: TVDevice?
    @Published private(set) var savedDevices: [TVDevice] = []
    
    // MARK: - Private Properties
    private var activeConnector: TVConnector?
    private let maxFreeDevices = 1
    
    // Коннекторы для разных брендов
    private lazy var samsungConnector = SamsungConnector()
    private lazy var lgConnector = LGConnector()
    private lazy var hisenseConnector = HisenseConnector()
    private lazy var androidConnector = AndroidTVConnector()
    private lazy var mockAndroidConnector = MockAndroidTVConnector() // <- мок-сервер
    private lazy var rokuConnector = RokuConnector()
    private lazy var tclConnector = TCLConnector()
    private lazy var genericConnector = BaseConnector()
    
    // MARK: - Initialization
    private init() {
        loadSavedDevices()
        setupConnectorCallbacks()
    }
    
    private func setupConnectorCallbacks() {
        let connectors: [TVConnector] = [
            samsungConnector,
            lgConnector,
            hisenseConnector,
            rokuConnector,
            tclConnector,
            androidConnector,
            mockAndroidConnector,
            genericConnector
        ]
        
        for connector in connectors {
            connector.stateDidChange = { [weak self] state in
                Task { @MainActor in
                    self?.handleConnectorStateChange(state)
                }
            }
        }
    }
    
    private func handleConnectorStateChange(_ state: ConnectorState) {
        connectorState = state
        
        switch state {
        case .idle:
            connectionStatus = .disconnected
        case .connecting:
            connectionStatus = .connecting
        case .requestingPIN, .waitingForPIN:
            connectionStatus = .awaitingPIN
        case .verifyingPIN:
            connectionStatus = .connecting
        case .connected:
            connectionStatus = .connected
        case .failed(let error):
            connectionStatus = .error(error)
        }
    }
    
    // MARK: - Device Management
    var canAddMoreDevices: Bool {
        SubscriptionManager.shared.isSubscribed || savedDevices.count < maxFreeDevices
    }
    
    func addDevice(_ device: TVDevice) -> Bool {
        guard canAddMoreDevices else { return false }
        
        var newDevice = device
        newDevice.lastConnected = Date()
        
        if let index = savedDevices.firstIndex(where: { $0.id == device.id }) {
            savedDevices[index] = newDevice
        } else {
            savedDevices.append(newDevice)
        }
        
        saveDevices()
        return true
    }
    
    func removeDevice(_ device: TVDevice) {
        savedDevices.removeAll { $0.id == device.id }
        saveDevices()
        
        if connectedDevice?.id == device.id {
            disconnect()
        }
    }
    
    func updateDevice(_ device: TVDevice) {
        if let index = savedDevices.firstIndex(where: { $0.id == device.id }) {
            savedDevices[index] = device
            saveDevices()
        }
    }
    
    private func loadSavedDevices() {
        guard let data = UserDefaults.standard.data(forKey: "saved_devices"),
              let devices = try? JSONDecoder().decode([TVDevice].self, from: data) else { return }
        savedDevices = devices
    }
    
    private func saveDevices() {
        guard let data = try? JSONEncoder().encode(savedDevices) else { return }
        UserDefaults.standard.set(data, forKey: "saved_devices")
    }
    
    // MARK: - Connection
    func connect(to device: TVDevice) async -> Bool {
        disconnect()
        
        // Выбираем подходящий коннектор
        activeConnector = connector(for: device.brand)
        
        // Подключаемся
        let success = await activeConnector?.connect(to: device) ?? false
        
        if success {
            connectedDevice = device
            var updated = device
            updated.lastConnected = Date()
            _ = addDevice(updated)
            AnalyticsService.shared.trackEvent(.deviceConnected, properties: ["brand": device.brand.rawValue])
        } else {
            AnalyticsService.shared.trackEvent(.deviceConnectionFailed, properties: ["brand": device.brand.rawValue])
        }
        
        return success
    }
    
    func disconnect() {
        activeConnector?.disconnect()
        activeConnector = nil
        connectionStatus = .disconnected
        connectorState = .idle
        connectedDevice = nil
    }
    
    private func connector(for brand: TVBrand) -> TVConnector {
        switch brand {
        case .samsung: return samsungConnector
        case .lg: return lgConnector
        case .hisense: return hisenseConnector
        case .roku: return rokuConnector
        case .tcl: return mockAndroidConnector
        default: return genericConnector
        }
    }
    
    // MARK: - Commands
    func sendCommand(_ button: RemoteButton) {
        guard connectionStatus.isConnected else { return }
        activeConnector?.sendCommand(button)
        AnalyticsService.shared.trackEvent(.remoteButtonPressed, properties: ["button": button.rawValue])
    }
    
    // MARK: - PIN Handling (for Hisense)
    func submitHisensePIN(_ pin: String) {
        Task {
            if let hisense = activeConnector as? HisenseConnector {
                let success = await hisense.submitPIN(pin)
                if success, let device = connectedDevice {
                    var updated = device
                    updated.lastConnected = Date()
                    _ = addDevice(updated)
                }
            }
        }
    }
    
    func connectHisenseWithoutPIN() {}
    
    func cancelHisensePairing() {
        activeConnector?.cancelPairing()
    }
}
