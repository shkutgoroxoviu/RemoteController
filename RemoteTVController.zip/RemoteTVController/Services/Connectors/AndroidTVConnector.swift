//
//  AndroidTVConnector.swift
//  RemoteTVController
//
//  Created by b on 22.12.2025.
//
import SwiftUI

@MainActor
final class AndroidTVConnector: BaseConnector {

    override var brand: TVBrand { .tcl } 

    private var device: TVDevice?

    override func connect(to device: TVDevice) async -> Bool {
        self.device = device
        state = .connecting("Connecting to Android TV via ADB...")

        do {
            let success = try await ADBClient.shared.connect(to: device.ipAddress)
            if success {
                state = .connected
                return true
            } else {
                state = .failed("ADB connection failed")
                return false
            }
        } catch {
            state = .failed("ADB error: \(error.localizedDescription)")
            return false
        }
    }

    override func sendCommand(_ button: RemoteButton) {
        guard let keycode = androidKeyCode(for: button) else { return }
        Task { @MainActor in
            await ADBClient.shared.sendKeyEvent(keycode)
        }
    }

    private func androidKeyCode(for button: RemoteButton) -> Int? {
        switch button {
        case .power: return 26
        case .up: return 19
        case .down: return 20
        case .left: return 21
        case .right: return 22
        case .ok: return 23
        case .back: return 4
        case .home: return 3
        case .menu: return 1
        case .volumeUp: return 24
        case .volumeDown: return 25
        case .mute: return 164
        case .play: return 126
        case .pause: return 127
        case .stop: return 86
        case .rewind: return 89
        case .fastForward: return 90
        default: return nil
        }
    }
}


actor ADBClient {
    static let shared = ADBClient()
    private var isConnected = false
    private var ipAddress: String?

    private init() {}

    func connect(to ip: String) async throws -> Bool {
        // Здесь можно реализовать TCP соединение с Android TV через ADB
        self.ipAddress = ip

        // Мок-логика: эмулируем подключение
        try await Task.sleep(nanoseconds: 1_000_000_000)
        isConnected = true
        return isConnected
    }

    func sendKeyEvent(_ keycode: Int) {
        guard isConnected, let ip = ipAddress else { return }
        // Отправка команды по ADB TCP
        print("Sending key \(keycode) to \(ip)")
        // В реале: TCP/ADB протокол тут
    }

    func disconnect() {
        isConnected = false
        ipAddress = nil
    }
}

import Network

final class MockAndroidTVServer {
    static let shared = MockAndroidTVServer()
    
    private var listener: NWListener?
    private var connections: [NWConnection] = []

    private init() {}

    func start(port: UInt16 = 5555) {
        do {
            let params = NWParameters.tcp
            listener = try NWListener(using: params, on: NWEndpoint.Port(rawValue: port)!)
            
            listener?.newConnectionHandler = { [weak self] connection in
                self?.setupConnection(connection)
            }
            
            listener?.start(queue: .global())
            print("📺 Mock Android TV Server started on port \(port)")
        } catch {
            print("❌ Failed to start mock server: \(error)")
        }
    }

    func stop() {
        listener?.cancel()
        connections.forEach { $0.cancel() }
        connections.removeAll()
        print("🛑 Mock Android TV Server stopped")
    }

    private func setupConnection(_ connection: NWConnection) {
        connections.append(connection)
        connection.start(queue: .global())
        print("🔌 New device connected: \(connection.endpoint)")
        receive(on: connection)
    }

    private func receive(on connection: NWConnection) {
        connection.receive(minimumIncompleteLength: 1, maximumLength: 1024) { [weak self] data, _, isComplete, error in
            if let data = data, let text = String(data: data, encoding: .utf8) {
                print("⬅ Received: \(text)")
            }
            
            if isComplete || error != nil {
                connection.cancel()
                self?.connections.removeAll { $0 === connection }
                print("❌ Connection closed")
            } else {
                self?.receive(on: connection)
            }
        }
    }

    func sendMockEvent(_ message: String) {
        let data = message.data(using: .utf8)!
        for connection in connections {
            connection.send(content: data, completion: .contentProcessed({ _ in }))
        }
        print("➡ Sent: \(message)")
    }
}

@MainActor
final class MockAndroidTVConnector: BaseConnector {

    override var brand: TVBrand { .tcl }

    private var connectedDevice: TVDevice?

    override func connect(to device: TVDevice) async -> Bool {
        disconnect()
        connectedDevice = device
        state = .connecting("Connecting to Mock Android TV...")

        // Запускаем мок-сервер, если он еще не запущен
        MockAndroidTVServer.shared.start(port: 5555)

        // Имитируем задержку подключения
        try? await Task.sleep(nanoseconds: 1_000_000_000) // 1 секунда

        state = .connected
        return true
    }

    override func disconnect() {
        state = .idle
        connectedDevice = nil
    }

    override func sendCommand(_ button: RemoteButton) {
        guard let device = connectedDevice else { return }
        let message = "KEY_\(button.rawValue)"
        MockAndroidTVServer.shared.sendMockEvent(message)
        print("📤 Sent command to \(device.name): \(message)")
    }
}
