//
//  RemoteView.swift
//  RemoteTVController
//

import SwiftUI

struct RemoteView: View {
    @EnvironmentObject var appState: AppState
    @EnvironmentObject var tvManager: TVConnectionManager
    @StateObject private var viewModel = RemoteViewModel()
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            if viewModel.connectionStatus.isConnected {
                RadialGradient(colors: [Color.green.opacity(0.15), .clear], center: .top, startRadius: 0, endRadius: 300).ignoresSafeArea()
            }
            
            VStack(spacing: 0) {
                topSection
                Spacer()
                NavigationPadView { sendCommand($0) }
                Spacer().frame(height: 24)
                controlButtonsRow
                Spacer().frame(height: 24)
                volumeChannelRow
                Spacer()
                ConnectionStatusView(status: viewModel.connectionStatus, deviceName: tvManager.connectedDevice?.name).padding(.bottom, 8)
            }
            .padding(.horizontal, 24)
            .padding(.top, 16)
        }
        .alert("Connection Error", isPresented: $viewModel.showError) {
            Button("Try Again") { viewModel.reconnectToLastDevice() }
            Button("Cancel", role: .cancel) {}
        } message: { Text(viewModel.errorMessage) }
    }
    
    private var topSection: some View {
        HStack(spacing: 16) {
            RemoteButtonView(button: .power, size: 50) { sendCommand(.power) }
            Spacer()
            Button {
                if !SubscriptionManager.shared.isSubscribed { appState.triggerPaywall(for: .premiumFeature) }
            } label: {
                Text("PRO").font(.system(size: 12, weight: .bold)).foregroundColor(.white)
                    .padding(.horizontal, 16).padding(.vertical, 10)
                    .background(Color(white: 0.2)).cornerRadius(20)
            }
            Spacer()
            NavigationLink(destination: DeviceSearchView()) {
                ZStack {
                    Circle().fill(viewModel.connectionStatus.isConnected ? Color.blue.opacity(0.8) : Color(white: 0.2)).frame(width: 50, height: 50)
                    Image(systemName: "wifi").font(.system(size: 20, weight: .medium)).foregroundColor(.white)
                }
            }
        }
    }
    
    private var controlButtonsRow: some View {
        HStack(spacing: 24) {
            controlButton(icon: "arrow.uturn.backward", button: .back)
            controlButton(icon: "house", button: .home)
            Button { sendCommand(.exit) } label: {
                Text("EXIT").font(.system(size: 12, weight: .semibold)).foregroundColor(.white)
                    .frame(width: 50, height: 50).background(Color(white: 0.15)).cornerRadius(25)
            }
        }
    }
    
    private func controlButton(icon: String, button: RemoteButton) -> some View {
        Button { sendCommand(button) } label: {
            ZStack {
                Circle().fill(Color(white: 0.15)).frame(width: 50, height: 50)
                Image(systemName: icon).font(.system(size: 18, weight: .medium)).foregroundColor(.white)
            }
        }
    }
    
    private var volumeChannelRow: some View {
        HStack(spacing: 0) {
            volumeControl
            VStack { Text("VOL").font(.system(size: 10, weight: .medium)).foregroundColor(.white.opacity(0.4)) }.frame(width: 40)
            Spacer()
            Button { sendCommand(.mute) } label: {
                ZStack {
                    Circle().fill(Color(white: 0.15)).frame(width: 50, height: 50)
                    Image(systemName: "speaker.slash").font(.system(size: 18, weight: .medium)).foregroundColor(.white)
                }
            }
            Spacer()
            VStack { Text("CH").font(.system(size: 10, weight: .medium)).foregroundColor(.white.opacity(0.4)) }.frame(width: 40)
            channelControl
        }
    }
    
    private var volumeControl: some View {
        VStack(spacing: 0) {
            Button { sendCommand(.volumeUp) } label: { Image(systemName: "speaker.plus").font(.system(size: 16)).foregroundColor(.white).frame(width: 60, height: 44) }
            Text("MENU").font(.system(size: 10, weight: .medium)).foregroundColor(.white.opacity(0.5)).frame(width: 60, height: 32).onTapGesture { sendCommand(.menu) }
            Button { sendCommand(.volumeDown) } label: { Image(systemName: "speaker.minus").font(.system(size: 16)).foregroundColor(.white).frame(width: 60, height: 44) }
        }.background(Color(white: 0.12)).cornerRadius(30)
    }
    
    private var channelControl: some View {
        VStack(spacing: 0) {
            Button { sendCommand(.channelUp) } label: { Image(systemName: "chevron.up").font(.system(size: 16)).foregroundColor(.white).frame(width: 60, height: 44) }
            Button { sendCommand(.source) } label: { Image(systemName: "rectangle.on.rectangle").font(.system(size: 14)).foregroundColor(.white.opacity(0.7)).frame(width: 60, height: 32) }
            Button { sendCommand(.channelDown) } label: { Image(systemName: "chevron.down").font(.system(size: 16)).foregroundColor(.white).frame(width: 60, height: 44) }
        }.background(Color(white: 0.12)).cornerRadius(30)
    }
    
    private func sendCommand(_ button: RemoteButton) {
        if viewModel.isPremiumButton(button) {
            appState.triggerPaywall(for: .premiumFeature)
            return
        }
        HapticService.shared.remoteButtonPressed()
        viewModel.sendCommand(button)
    }
}


