//
//  SettingsView.swift
//  RemoteTVController
//

import SwiftUI

struct SettingsView: View {
    @StateObject private var viewModel = SettingsViewModel()
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            
            ScrollView {
                VStack(spacing: 24) {
                    settingsSection(title: "ACCOUNT") {
                        settingsRow(icon: "creditcard", title: "Manage Subscription", action: viewModel.openManageSubscription)
                        settingsRow(icon: "questionmark.circle", title: "Support", action: viewModel.openSupport)
                    }
                    
                    settingsSection(title: "LEGAL") {
                        settingsRow(icon: "doc.text", title: "Terms of Service", action: viewModel.openTerms)
                        settingsRow(icon: "lock.shield", title: "Privacy policy", action: viewModel.openPrivacy)
                    }
                    
                    settingsSection(title: "ABOUT") {
                        settingsRow(icon: "star", title: "Rate us", action: viewModel.rateApp)
                        settingsRow(icon: "square.and.arrow.up", title: "Share the app", action: viewModel.shareApp)
                    }
                    
                    Text("Application version: \(viewModel.appVersion)")
                        .font(.system(size: 12)).foregroundColor(.white.opacity(0.3)).padding(.top, 16)
                }.padding(.horizontal, 24).padding(.top, 16)
            }
        }
        .navigationTitle("Settings").navigationBarTitleDisplayMode(.large)
        .sheet(isPresented: $viewModel.showRateUs) { RateUsView(viewModel: viewModel) }
        .sheet(isPresented: $viewModel.showShareSheet) { ShareSheet(items: [viewModel.appStoreURL]) }
    }
    
    private func settingsSection(title: String, @ViewBuilder content: () -> some View) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title).font(.system(size: 12, weight: .medium)).foregroundColor(.white.opacity(0.4)).padding(.leading, 4)
            VStack(spacing: 0) { content() }.background(RoundedRectangle(cornerRadius: 12).fill(Color(white: 0.1)))
        }
    }
    
    private func settingsRow(icon: String, title: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 12) {
                Image(systemName: icon).font(.system(size: 16, weight: .medium)).foregroundColor(.white.opacity(0.7)).frame(width: 24)
                Text(title).font(.system(size: 16)).foregroundColor(.white)
                Spacer()
                Image(systemName: "chevron.right").font(.system(size: 12, weight: .medium)).foregroundColor(.white.opacity(0.3))
            }.padding(16)
        }
    }
}

struct RateUsView: View {
    @ObservedObject var viewModel: SettingsViewModel
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color.black.ignoresSafeArea()
                VStack(spacing: 32) {
                    Spacer()
                    ZStack {
                        ForEach(0..<5, id: \.self) { i in
                            Image(systemName: "star.fill").font(.system(size: 16)).foregroundColor(.purple.opacity(0.8))
                                .offset(x: CGFloat([-40, -20, 0, 20, 40][i]), y: CGFloat([-30, -40, -45, -40, -30][i]))
                        }
                        Circle().stroke(LinearGradient(colors: [.purple, .pink], startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 4)
                            .frame(width: 100, height: 100)
                            .overlay(VStack(spacing: 12) {
                                HStack(spacing: 24) { Circle().fill(Color.purple).frame(width: 8, height: 8); Circle().fill(Color.purple).frame(width: 8, height: 8) }
                                Path { path in path.move(to: CGPoint(x: 25, y: 0)); path.addQuadCurve(to: CGPoint(x: 55, y: 0), control: CGPoint(x: 40, y: 20)) }
                                    .stroke(Color.purple, lineWidth: 3).frame(width: 80, height: 20)
                            })
                    }
                    Text("Love the app?").font(.system(size: 22, weight: .bold)).foregroundColor(.white)
                    Text("Your rating means a lot. Help others discover it!").font(.system(size: 15)).foregroundColor(.white.opacity(0.6)).multilineTextAlignment(.center).padding(.horizontal, 40)
                    Spacer()
                    PrimaryButton(title: "RATE THE APP", style: .filled) { viewModel.submitRating(); dismiss() }.padding(.horizontal, 24)
                    Button("NOT NOW") { dismiss() }.font(.system(size: 14, weight: .medium)).foregroundColor(.white.opacity(0.5)).padding(.bottom, 24)
                }
            }
            .navigationTitle("Rate us").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .navigationBarLeading) { Button { dismiss() } label: { Image(systemName: "chevron.left").foregroundColor(.white) } } }
        }
    }
}

struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController { UIActivityViewController(activityItems: items, applicationActivities: nil) }
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}


