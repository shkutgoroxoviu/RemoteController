//
//  RemoteButtonView.swift
//  RemoteTVController
//

import SwiftUI

struct RemoteButtonView: View {
    let button: RemoteButton
    let size: CGFloat
    let action: () -> Void
    @State private var isPressed = false
    
    var body: some View {
        Button(action: action) {
            ZStack {
                Circle()
                    .fill(button == .power ? Color.red.opacity(0.9) : Color(white: 0.2))
                    .frame(width: size, height: size)
                    .shadow(color: .black.opacity(0.3), radius: isPressed ? 2 : 4, y: isPressed ? 1 : 2)
                
                Image(systemName: button.sfSymbol)
                    .font(.system(size: size * 0.4, weight: .semibold))
                    .foregroundColor(.white)
            }
        }
        .scaleEffect(isPressed ? 0.95 : 1.0)
        .animation(.easeInOut(duration: 0.1), value: isPressed)
        .simultaneousGesture(
            DragGesture(minimumDistance: 0)
                .onChanged { _ in isPressed = true }
                .onEnded { _ in isPressed = false }
        )
    }
}

struct NavigationPadView: View {
    let onButton: (RemoteButton) -> Void
    
    var body: some View {
        ZStack {
            Circle().fill(Color(white: 0.15)).frame(width: 200, height: 200)
            
            Button { onButton(.ok) } label: {
                ZStack {
                    Circle().fill(Color(white: 0.25)).frame(width: 70, height: 70)
                    Text("OK").font(.system(size: 18, weight: .bold)).foregroundColor(.white)
                }
            }
            
            VStack {
                Button { onButton(.up) } label: {
                    Image(systemName: "chevron.up").font(.system(size: 24, weight: .semibold)).foregroundColor(.white).frame(width: 50, height: 50)
                }
                Spacer()
                Button { onButton(.down) } label: {
                    Image(systemName: "chevron.down").font(.system(size: 24, weight: .semibold)).foregroundColor(.white).frame(width: 50, height: 50)
                }
            }.frame(height: 200)
            
            HStack {
                Button { onButton(.left) } label: {
                    Image(systemName: "chevron.left").font(.system(size: 24, weight: .semibold)).foregroundColor(.white).frame(width: 50, height: 50)
                }
                Spacer()
                Button { onButton(.right) } label: {
                    Image(systemName: "chevron.right").font(.system(size: 24, weight: .semibold)).foregroundColor(.white).frame(width: 50, height: 50)
                }
            }.frame(width: 200)
        }
    }
}

#Preview {
    ZStack {
        Color.black.ignoresSafeArea()
        VStack(spacing: 30) {
            RemoteButtonView(button: .power, size: 50) {}
            NavigationPadView { _ in }
        }
    }
}


