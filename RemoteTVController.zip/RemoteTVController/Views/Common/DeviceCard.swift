//
//  DeviceCard.swift
//  RemoteTVController
//

import SwiftUI

struct DeviceCard: View {
    let device: TVDevice
    let isConnected: Bool
    let isOffline: Bool
    var showActions: Bool = false
    var onTap: () -> Void
    var onManage: (() -> Void)? = nil
    var onDelete: (() -> Void)? = nil
    
    private var brandColor: Color {
        switch device.brand {
        case .samsung: return .blue
        case .lg: return .red
        case .sony: return .purple
        case .hisense: return .green
        case .philips: return .orange
        case .panasonic: return .cyan
        case .tcl: return .teal
        case .roku: return .indigo
        case .unknown: return .gray
        }
    }
    
    var body: some View {
        Button(action: onTap) {
            HStack(spacing: 12) {
                ZStack {
                    RoundedRectangle(cornerRadius: 8)
                        .fill(brandColor.opacity(0.2))
                        .frame(width: 44, height: 44)
                    Image(systemName: "tv")
                        .font(.system(size: 18, weight: .medium))
                        .foregroundColor(brandColor)
                }
                
                VStack(alignment: .leading, spacing: 4) {
                    Text(device.name)
                        .font(.system(size: 16, weight: .medium))
                        .foregroundColor(.white)
                    Text(device.ipAddress)
                        .font(.system(size: 12))
                        .foregroundColor(.white.opacity(0.5))
                }
                
                Spacer()
                
                if showActions {
                    HStack(spacing: 12) {
                        if isConnected { statusBadge }
                        if let onManage {
                            Button(action: onManage) {
                                Image(systemName: "ellipsis")
                                    .font(.system(size: 16))
                                    .foregroundColor(.white.opacity(0.6))
                                    .frame(width: 32, height: 32)
                                    .background(Color(white: 0.25))
                                    .cornerRadius(8)
                            }
                        }
                        if let onDelete {
                            Button(action: onDelete) {
                                Image(systemName: "trash")
                                    .font(.system(size: 14))
                                    .foregroundColor(.red)
                                    .frame(width: 32, height: 32)
                                    .background(Color.red.opacity(0.15))
                                    .cornerRadius(8)
                            }
                        }
                    }
                } else {
                    if isConnected {
                        statusBadge
                    } else if isOffline {
                        offlineBadge
                    } else {
                        Image(systemName: "chevron.right")
                            .font(.system(size: 14))
                            .foregroundColor(.white.opacity(0.3))
                    }
                }
            }
            .padding(16)
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .fill(Color(white: 0.12))
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(isConnected ? Color.green.opacity(0.3) : .clear, lineWidth: 1)
                    )
            )
        }
        .buttonStyle(.plain)
    }
    
    private var statusBadge: some View {
        Text("Connected")
            .font(.system(size: 11, weight: .semibold))
            .foregroundColor(.green)
            .padding(.horizontal, 10)
            .padding(.vertical, 5)
            .background(Color.green.opacity(0.15))
            .cornerRadius(12)
    }
    
    private var offlineBadge: some View {
        Text("Offline")
            .font(.system(size: 11, weight: .medium))
            .foregroundColor(.white.opacity(0.4))
            .padding(.horizontal, 10)
            .padding(.vertical, 5)
            .background(Color.white.opacity(0.1))
            .cornerRadius(12)
    }
}

// MARK: - Discovered Device Card

struct DiscoveredDeviceCard: View {
    let device: DiscoveredDevice
    let isConnecting: Bool
    var connectionStep: String? = nil
    let onTap: () -> Void
    
    private var brandColor: Color {
        switch device.brand {
        case .samsung: return .blue
        case .lg: return .red
        case .sony: return .purple
        case .hisense: return .green
        case .philips: return .orange
        case .panasonic: return .cyan
        case .tcl: return .teal
        case .roku: return .indigo
        case .unknown: return .gray
        }
    }
    
    var body: some View {
        Button(action: onTap) {
            VStack(spacing: 0) {
                HStack(spacing: 12) {
                    // TV Icon
                    ZStack {
                        RoundedRectangle(cornerRadius: 8)
                            .fill(brandColor.opacity(0.2))
                            .frame(width: 44, height: 44)
                        
                        if isConnecting {
                            ProgressView()
                                .scaleEffect(0.7)
                                .tint(brandColor)
                        } else {
                            Image(systemName: "tv")
                                .font(.system(size: 18))
                                .foregroundColor(brandColor)
                        }
                    }
                    
                    // Device Info
                    VStack(alignment: .leading, spacing: 4) {
                        HStack(spacing: 6) {
                            Text(device.name)
                                .font(.system(size: 16, weight: .medium))
                                .foregroundColor(.white)
                            
                            if device.brand != .unknown {
                                Text(device.brand.displayName)
                                    .font(.system(size: 10, weight: .semibold))
                                    .foregroundColor(brandColor)
                                    .padding(.horizontal, 6)
                                    .padding(.vertical, 2)
                                    .background(brandColor.opacity(0.15))
                                    .cornerRadius(4)
                            }
                        }
                        
                        Text(device.ipAddress)
                            .font(.system(size: 12))
                            .foregroundColor(.white.opacity(0.5))
                    }
                    
                    Spacer()
                    
                    // Status indicator
                    if isConnecting {
                        Text("Connecting...")
                            .font(.system(size: 11, weight: .medium))
                            .foregroundColor(brandColor)
                            .padding(.horizontal, 8)
                            .padding(.vertical, 4)
                            .background(brandColor.opacity(0.15))
                            .cornerRadius(6)
                    } else {
                        Image(systemName: "chevron.right")
                            .font(.system(size: 14))
                            .foregroundColor(.white.opacity(0.3))
                    }
                }
                .padding(16)
                
                // Connection step indicator
                if isConnecting, let step = connectionStep {
                    HStack(spacing: 8) {
                        ProgressView()
                            .scaleEffect(0.6)
                            .tint(.white.opacity(0.6))
                        
                        Text(step)
                            .font(.system(size: 11))
                            .foregroundColor(.white.opacity(0.6))
                        
                        Spacer()
                    }
                    .padding(.horizontal, 16)
                    .padding(.bottom, 12)
                    .transition(.opacity.combined(with: .move(edge: .top)))
                }
            }
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .fill(Color(white: 0.12))
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(isConnecting ? brandColor.opacity(0.3) : .clear, lineWidth: 1)
                    )
            )
            .animation(.easeInOut(duration: 0.3), value: isConnecting)
            .animation(.easeInOut(duration: 0.3), value: connectionStep)
        }
        .buttonStyle(.plain)
        .disabled(isConnecting)
    }
}
