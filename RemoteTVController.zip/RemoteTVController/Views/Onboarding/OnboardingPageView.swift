//
//  OnboardingPageView.swift
//  RemoteTVController
//

import SwiftUI

struct OnboardingPageView: View {
    let page: OnboardingPage
    
    var body: some View {
        VStack(spacing: 0) {
            Spacer()
            illustration.frame(height: 360)
            Spacer()
            
            Text(page.title)
                .font(.system(size: 24, weight: .bold))
                .foregroundColor(.white)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 32)
            
            Text(page.description)
                .font(.system(size: 15))
                .foregroundColor(.white.opacity(0.7))
                .multilineTextAlignment(.center)
                .padding(.horizontal, 32)
                .padding(.top, 12)
            
            Spacer().frame(height: 100)
        }
    }
    
    @ViewBuilder
    private var illustration: some View {
        switch page.id {
        case 0: welcomeIllustration
        case 1: connectingIllustration
        case 2: searchingIllustration
        case 3: reviewsIllustration
        default: EmptyView()
        }
    }
    
    private var welcomeIllustration: some View {
        VStack(spacing: 16) {
            ZStack {
                RoundedRectangle(cornerRadius: 24).fill(Color(white: 0.1)).frame(width: 160, height: 300)
                    .overlay(RoundedRectangle(cornerRadius: 24).stroke(Color.white.opacity(0.1), lineWidth: 1))
                
                VStack(spacing: 12) {
                    HStack(spacing: 20) {
                        Circle().fill(Color.red.opacity(0.8)).frame(width: 28, height: 28)
                        RoundedRectangle(cornerRadius: 8).fill(Color.white.opacity(0.15)).frame(width: 40, height: 24)
                        Circle().fill(Color.blue.opacity(0.5)).frame(width: 28, height: 28)
                    }
                    Circle().fill(Color(white: 0.15)).frame(width: 100, height: 100)
                        .overlay(Circle().fill(Color(white: 0.25)).frame(width: 40, height: 40))
                    HStack(spacing: 16) {
                        ForEach(0..<3, id: \.self) { _ in
                            Circle().fill(Color(white: 0.2)).frame(width: 32, height: 32)
                        }
                    }
                }
            }
            
            HStack(spacing: 20) {
                ForEach(["SAMSUNG", "LG", "SONY", "Roku"], id: \.self) { brand in
                    Text(brand).font(.system(size: 10, weight: .medium)).foregroundColor(.white.opacity(0.4))
                }
            }
        }
    }
    
    private var connectingIllustration: some View {
        VStack(spacing: 24) {
            ZStack {
                RoundedRectangle(cornerRadius: 24).fill(Color(white: 0.1)).frame(width: 160, height: 300)
                VStack(spacing: 16) {
                    HStack(spacing: 20) {
                        Circle().fill(Color.red.opacity(0.6)).frame(width: 28, height: 28)
                        RoundedRectangle(cornerRadius: 8).fill(Color.white.opacity(0.15)).frame(width: 40, height: 24)
                            .overlay(Text("PRO").font(.system(size: 8, weight: .bold)).foregroundColor(.white.opacity(0.6)))
                        Circle().fill(Color.blue.opacity(0.4)).frame(width: 28, height: 28)
                    }
                    Circle().fill(Color(white: 0.15)).frame(width: 90, height: 90)
                        .overlay(Circle().fill(Color(white: 0.25)).frame(width: 36, height: 36).overlay(Text("OK").font(.system(size: 8, weight: .bold)).foregroundColor(.white)))
                }
            }
            
            HStack(spacing: 8) {
                Image(systemName: "wifi").font(.system(size: 14))
                Text("Connect to TV").font(.system(size: 12))
            }
            .foregroundColor(.white.opacity(0.5))
            .padding(.horizontal, 16).padding(.vertical, 8)
            .background(Color.white.opacity(0.1)).cornerRadius(20)
        }
    }
    
    private var searchingIllustration: some View {
        ZStack {
            ForEach(0..<3, id: \.self) { i in
                Circle().stroke(Color.blue.opacity(0.4 - Double(i) * 0.1), lineWidth: 2)
                    .frame(width: CGFloat(120 + i * 60), height: CGFloat(120 + i * 60))
            }
            ZStack {
                Circle().fill(Color.blue.opacity(0.2)).frame(width: 80, height: 80)
                Image(systemName: "tv").font(.system(size: 32, weight: .medium)).foregroundColor(.blue)
            }
        }
    }
    
    private var reviewsIllustration: some View {
        VStack(spacing: 16) {
            ForEach(0..<3, id: \.self) { i in
                reviewCard(index: i)
            }
        }.padding(.horizontal, 24)
    }
    
    private func reviewCard(index: Int) -> some View {
        let reviews = [
            ("Daniel Roberts", "Auto-scan found all TVs in the house instantly. Switching between them is super easy.", 5),
            ("Christopher Hayes", "Clean interface, no clutter. I upgraded to Pro for multiple TVs — worth it.", 5),
            ("Emily Harrison", "Love the design. Simple and connected to my Apple TV with zero issues.", 5)
        ]
        let review = reviews[index % reviews.count]
        
        return HStack(alignment: .top, spacing: 12) {
            Circle().fill(Color(white: 0.2)).frame(width: 36, height: 36)
                .overlay(Text(String(review.0.prefix(1))).font(.system(size: 14, weight: .semibold)).foregroundColor(.white.opacity(0.6)))
            
            VStack(alignment: .leading, spacing: 4) {
                HStack {
                    Text(review.0).font(.system(size: 13, weight: .semibold)).foregroundColor(.white)
                    Spacer()
                    HStack(spacing: 2) {
                        ForEach(0..<review.2, id: \.self) { _ in
                            Image(systemName: "star.fill").font(.system(size: 10)).foregroundColor(.yellow)
                        }
                    }
                }
                Text(review.1).font(.system(size: 12)).foregroundColor(.white.opacity(0.6)).lineLimit(2)
            }
        }
        .padding(12)
        .background(RoundedRectangle(cornerRadius: 12).fill(Color(white: 0.1)))
    }
}


