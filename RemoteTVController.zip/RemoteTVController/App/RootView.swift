//
//  RootView.swift
//  RemoteTVController
//

import SwiftUI

struct RootView: View {
    @EnvironmentObject var appState: AppState
    @EnvironmentObject var subscriptionManager: SubscriptionManager
    
    var body: some View {
        ZStack {
            if !appState.hasCompletedOnboarding {
                OnboardingContainerView()
            } else {
                MainTabView()
            }
        }
        .fullScreenCover(isPresented: $appState.showPaywall) {
            PaywallView(trigger: appState.paywallTrigger)
        }
    }
}

#Preview {
    RootView()
        .environmentObject(AppState())
        .environmentObject(SubscriptionManager.shared)
        .environmentObject(TVConnectionManager.shared)
}


