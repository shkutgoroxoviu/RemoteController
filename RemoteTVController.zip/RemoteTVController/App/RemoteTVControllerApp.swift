//
//  RemoteTVControllerApp.swift
//  RemoteTVController
//
//  Created for 5032 Remote TV Controller
//

import SwiftUI

@main
struct RemoteTVControllerApp: App {
    @StateObject private var appState = AppState()
    @StateObject private var subscriptionManager = SubscriptionManager.shared
    @StateObject private var tvManager = TVConnectionManager.shared
    
    init() {
        MockAndroidTVServer.shared.start(port: 5555)
        
        let mockDevice = TVDevice(
            name: "Mock Android TV",
            ipAddress: "127.0.0.1",
            brand: .tcl,
            model: "MockTV 1"
        )
        
        // Добавляем его сразу в сохранённые устройства
        TVConnectionManager.shared.addDevice(mockDevice)
        AnalyticsService.shared.initialize()
        SubscriptionManager.shared.initialize()
        AnalyticsService.shared.trackEvent(.appLaunched)
    }
    
    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(appState)
                .environmentObject(subscriptionManager)
                .environmentObject(tvManager)
                .preferredColorScheme(.dark)
        }
    }
}


